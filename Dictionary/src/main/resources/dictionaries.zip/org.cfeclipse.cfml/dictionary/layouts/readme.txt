The files in here should actually be under each language version. 
So that layouts for tags are language version specific