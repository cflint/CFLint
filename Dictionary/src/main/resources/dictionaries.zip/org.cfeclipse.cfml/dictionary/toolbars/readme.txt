The files in here should actually be under each language version. 
So that tabs and buttons are version specific